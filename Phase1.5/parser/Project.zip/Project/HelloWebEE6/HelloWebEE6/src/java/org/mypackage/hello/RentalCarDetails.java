/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.mypackage.hello;

/**
 *
 * @author priya
 */
public class RentalCarDetails {
        private String RentalCarID;
	private String ModelName;
	private String Color;
	private String Year;
	private String Price;
        private String RatePerDay;
        private String Availability;

    /**
     * @return the DealersCarID
     */
    public String getRentalCarID() {
        return RentalCarID;
    }

    
    public void setRentalCarID(String RentalCarID) {
        this.RentalCarID = RentalCarID;
    }

    /**
     * @return the ModelName
     */
    public String getModelName() {
        return ModelName;
    }

    /**
     * @param ModelName the ModelName to set
     */
    public void setModelName(String ModelName) {
        this.ModelName = ModelName;
    }

    /**
     * @return the Color
     */
    public String getColor() {
        return Color;
    }

    /**
     * @param Color the Color to set
     */
    public void setColor(String Color) {
        this.Color = Color;
    }

    /**
     * @return the Year
     */
    public String getYear() {
        return Year;
    }

    /**
     * @param Year the Year to set
     */
    public void setYear(String Year) {
        this.Year = Year;
    }

    /**
     * @return the Price
     */
    public String getPrice() {
        return Price;
    }

    /**
     * @param Price the Price to set
     */
    public void setPrice(String Price) {
        this.Price = Price;
    }

    /**
     * @return the RatePerDay
     */
    public String getRatePerDay() {
        return RatePerDay;
    }

    /**
     * @param RatePerDay the RatePerDay to set
     */
    public void setRatePerDay(String RatePerDay) {
        this.RatePerDay = RatePerDay;
    }

    /**
     * @return the Availability
     */
    public String getAvailability() {
        return Availability;
    }

    /**
     * @param Availability the Availability to set
     */
    public void setAvailability(String Availability) {
        this.Availability = Availability;
    }
}
