package org.mypackage.hello;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


/**
 *
 * @author priya
 */
@WebServlet(urlPatterns = {"/CustomerParser"})
public class CustomerParser extends HttpServlet {

  List<CustomerDetails> CustomerObjectSet= new ArrayList<CustomerDetails>();
    CustomerDetails customer;
    static Statement statement = null;
    
    String elementValueRead;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        
SAXParserFactory factory = SAXParserFactory.newInstance();


DefaultHandler handler = new DefaultHandler(){
@Override
public void startElement(String str1, String str2, String elementName, Attributes attributes) throws SAXException {

        if (elementName.equalsIgnoreCase("Customer")) {
         
       customer= new CustomerDetails();
       customer.setCustomerID(attributes.getValue("CustomerID"));
       
           
        }


    }

@Override
    public void endElement(String str1, String str2, String element) throws SAXException {
 
        if (element.equals("Customer")) {
            CustomerObjectSet.add(customer);
             
	    return;
        }
         if (element.equalsIgnoreCase("CustomerName")) {
            customer.setCustomerName(elementValueRead);
            
	    return;
        }
        
        if (element.equalsIgnoreCase("Password")) {
            customer.setPassword(elementValueRead);
            
	    return;
        }
        if(element.equalsIgnoreCase("EmailID")){
           customer.setEmailID(elementValueRead);
            
	    return;
        }
        if(element.equalsIgnoreCase("Contact")){
            customer.setContact(elementValueRead);
           
	    return;
        }
        if(element.equalsIgnoreCase("StAdd")){
            
            customer.setStAdd(elementValueRead);
	    return;
        }
        if(element.equalsIgnoreCase("City")){
            customer.setCity(elementValueRead);
            
	    return;
        }
         if(element.equalsIgnoreCase("State")){
            customer.setState(elementValueRead);
            
	    return;
        }
            if(element.equalsIgnoreCase("Zip")){
            customer.setZip(elementValueRead);
            
	    return;
        }
               if(element.equalsIgnoreCase("Country")){
            customer.setCountry(elementValueRead);
            
	    return;
        }

    }


@Override
    public void characters(char[] content, int begin, int end) throws SAXException {
    	
        elementValueRead = new String(content, begin, end);
    }

};
PrintWriter out=response.getWriter();

try {
	
            SAXParser parser = factory.newSAXParser();
            
            parser.parse("C:\\masters\\2nd semester\\SOA\\CarRequestServices\\CustomerDetails.xml", handler);
            

        } 
catch (ParserConfigurationException e) {
            out.println(e.getMessage());
        } catch (SAXException e) {
            out.println(e.getMessage());
        }
try{
    
    
        for(CustomerDetails l : CustomerObjectSet)
        {
         
         int custid= Integer.parseInt(l.getCustomerID());
        
          //int contact= Integer.parseInt(l.getContact());
         
         //int zip= Integer.parseInt(l.getZip());
         
                    
            Connector connect = new Connector();
            
            connect.getConnection();
            
            statement = connect.getConnection().createStatement();
			String cussql = "INSERT INTO customerDetails (customerID, CustomerName, Password, emailID, contact, StAdd, City, State, Zip)"
					+ "VALUES ('" + custid + "','" + l.getCustomerName() + "','" + l.getPassword() + "','" + l.getEmailID()
					+ "','" + l.getContact() + "','" + l.getStAdd() + "','" + l.getCity() + "','" + l.getState() + "'," + l.getZip() + ")";
			statement.executeUpdate(cussql);
			out.println("Query successfully executed!");		
			statement.close();
           
        }
}     catch (SQLException ex) {
          Logger.getLogger(CustomerParser.class.getName()).log(Level.SEVERE, null, ex);
      }
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
