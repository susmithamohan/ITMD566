package org.mypackage.hello;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import java.sql.Statement;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import static org.mypackage.hello.CustomerParser.statement;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


/**
 *
 * @author priya
 */
@WebServlet(urlPatterns = {"/PartsParser"})
public class PartsParser extends HttpServlet {

  List<PartsDetails> PartsObjectSet= new ArrayList<PartsDetails>();
    PartsDetails parts;
    
    String elementValueRead;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        
SAXParserFactory factory = SAXParserFactory.newInstance();


DefaultHandler handler = new DefaultHandler(){
@Override
public void startElement(String str1, String str2, String elementName, Attributes attributes) throws SAXException {

        if (elementName.equalsIgnoreCase("Parts")) {
         
       parts= new PartsDetails();
          parts.setPartID(attributes.getValue("PartID"));
       
           
        }


    }

@Override
    public void endElement(String str1, String str2, String element) throws SAXException {
 
        if (element.equals("Parts")) {
            PartsObjectSet.add(parts);
             
	    return;
        }
         if (element.equalsIgnoreCase("PartName")) {
            parts.setPartName(elementValueRead);
            
	    return;
        }
        
        if (element.equalsIgnoreCase("Quantity")) {
            parts.setQuantity(elementValueRead);
            
	    return;
        }
        if(element.equalsIgnoreCase("Cost")){
           parts.setCost(elementValueRead);
            
	    return;
        }
        

    }


@Override
    public void characters(char[] content, int begin, int end) throws SAXException {
    	
        elementValueRead = new String(content, begin, end);
    }

};
PrintWriter out=response.getWriter();

try {
	
            SAXParser parser = factory.newSAXParser();
            
            parser.parse("C:\\masters\\2nd semester\\SOA\\CarRequestServices\\PartsDetails.xml", handler);
            

       
        } 
catch (ParserConfigurationException e) {
            out.println(e.getMessage());
        } catch (SAXException e) {
            out.println(e.getMessage());
        }

 try{
    
    
        for(PartsDetails l : PartsObjectSet)
        {
         
         int partid= Integer.parseInt(l.getPartID());
        
          //int contact= Integer.parseInt(l.getContact());
         
         //int zip= Integer.parseInt(l.getZip());
         
                    
            Connector connect = new Connector();
            
            connect.getConnection();
            
            statement = connect.getConnection().createStatement();
			String partsql = "INSERT INTO PartsDetails (PartID , PartName , Quantity , Cost)"
					+ "VALUES ('" + partid + "','" + l.getPartName() + "','" + l.getQuantity() + "','" + l.getCost() + ")";
			statement.executeUpdate(partsql);
			out.println("Query successfully executed!");		
			statement.close();
           
        }
}     catch (SQLException ex) {
         out.println(ex);
      }
   

        
       
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

