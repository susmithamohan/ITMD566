/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.mypackage.hello;

/**
 *
 * @author priya
 */
public class OrderDetails {
        public String OrderID;
	private String DealersOrderID;
	private String RentalOrderID;
	private String PartOrderID;
	private String CustomerID;
	private String Price;

    /**
     * @return the DealersOrderID
     */
    public String getDealersOrderID() {
        return DealersOrderID;
    }

    /**
     * @param DealersOrderID the DealersOrderID to set
     */
    public void setDealersOrderID(String DealersOrderID) {
        this.DealersOrderID = DealersOrderID;
    }

    /**
     * @return the RentalOrderID
     */
    public String getRentalOrderID() {
        return RentalOrderID;
    }

    /**
     * @param RentalOrderID the RentalOrderID to set
     */
    public void setRentalOrderID(String RentalOrderID) {
        this.RentalOrderID = RentalOrderID;
    }

    /**
     * @return the PartOrderID
     */
    public String getPartOrderID() {
        return PartOrderID;
    }

    /**
     * @param PartOrderID the PartOrderID to set
     */
    public void setPartOrderID(String PartOrderID) {
        this.PartOrderID = PartOrderID;
    }

    /**
     * @return the CustomerID
     */
    public String getCustomerID() {
        return CustomerID;
    }

    /**
     * @param CustomerID the CustomerID to set
     */
    public void setCustomerID(String CustomerID) {
        this.CustomerID = CustomerID;
    }

    /**
     * @return the Price
     */
    public String getPrice() {
        return Price;
    }

    /**
     * @param Price the Price to set
     */
    public void setPrice(String Price) {
        this.Price = Price;
    }
}
