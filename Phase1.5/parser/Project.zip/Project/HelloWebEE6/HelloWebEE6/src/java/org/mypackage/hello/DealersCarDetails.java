/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.mypackage.hello;

/**
 *
 * @author priya
 */
public class DealersCarDetails {
        private String DealersCarID;
	private String ModelNumber;
	private String Color;
	private String Year;
	private String Price;

    /**
     * @return the DealersCarID
     */
    public String getDealersCarID() {
        return DealersCarID;
    }

    /**
     * @param DealersCarID the DealersCarID to set
     */
    public void setDealersCarID(String DealersCarID) {
        this.DealersCarID = DealersCarID;
    }

    /**
     * @return the MobileNumber
     */
    public String getModelNumber() {
        return ModelNumber;
    }
    /**
     * @param ModelNumber the ModelNumber to set
     */
    public void setModelNumber(String ModelNumber) {
        this.ModelNumber = ModelNumber;
    }
    

    /**
     * @return the Color
     */
    public String getColor() {
        return Color;
    }

    /**
     * @param Color the Color to set
     */
    public void setColor(String Color) {
        this.Color = Color;
    }

    /**
     * @return the Year
     */
    public String getYear() {
        return Year;
    }

    /**
     * @param Year the Year to set
     */
    public void setYear(String Year) {
        this.Year = Year;
    }

    /**
     * @return the Price
     */
    public String getPrice() {
        return Price;
    }

    /**
     * @param Price the Price to set
     */
    public void setPrice(String Price) {
        this.Price = Price;
    }

    
	
}
