/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.mypackage.hello;

/**
 *
 * @author priya
 */
public class PartsDetails {
        private String PartID;
	private String PartName;
	private String Quantity;
	private String Cost;

    /**
     * @return the PartID
     */
    public String getPartID() {
        return PartID;
    }

    /**
     * @param PartID the PartID to set
     */
    public void setPartID(String PartID) {
        this.PartID = PartID;
    }

    /**
     * @return the PartName
     */
    public String getPartName() {
        return PartName;
    }

    /**
     * @param PartName the PartName to set
     */
    public void setPartName(String PartName) {
        this.PartName = PartName;
    }

    /**
     * @return the Quantity
     */
    public String getQuantity() {
        return Quantity;
    }

    /**
     * @param Quantity the Quantity to set
     */
    public void setQuantity(String Quantity) {
        this.Quantity = Quantity;
    }

    /**
     * @return the Cost
     */
    public String getCost() {
        return Cost;
    }

    /**
     * @param Cost the Cost to set
     */
    public void setCost(String Cost) {
        this.Cost = Cost;
    }
	
}
